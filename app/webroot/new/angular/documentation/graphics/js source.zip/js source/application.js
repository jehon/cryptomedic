"use strict";

var app = {};
app.lists = {};
app.templates = {};

var cpready = jehon.checkpoint(); 

debug = function() {
    // jehon.picture.scan('#test');
    // jehon.picture.showCorners('#test');
}

jehon.ready(function() {
    jQuery('.menubar').append("<a id=trace href='javascript: location=location + \"?regenerate\";' class='textbutton debug'>Regenerate</a> ");
});

jehon.settings.templatehelpers.input = function(chunk, context, bodies, params) {
    if (amd.mode == "read")
        return jehon.settings.templatehelpers.view(chunk, context, bodies, params);
    else
        return jehon.settings.templatehelpers.edit(chunk, context, bodies, params);
}

jehon.settings.templatehelpers.view = function(chunk, context, bodies, params) {
    if (params.value == null) {
        return chunk.write('?');
    }
    switch(params.type) {
        case 'integer':
        case 'string':
            return chunk.write(params.value);
        case 'timestamp':
        case 'datetime':
            return chunk.write(params.value.substr(0, 10));
        case 'boolean':
            if (params.value > 0) {
                return chunk.write("<img src='/cryptomedic/img/boolean-true.gif' alt='yes'>");
            } else {
                return chunk.write("<img src='/cryptomedic/img/boolean-false.gif' alt='no'>");
            }
        case 'text':
            return chunk.write(params.value.replace("\n", "<br>"));
        case 'list':
            return chunk.write("LIST: " + params.value);
    }
    return chunk.write("view: " + params.type + " - " + params.value + " -");
};

jehon.settings.templatehelpers.edit = function(chunk, context, bodies, params) {
    //console.log(params);
    var required = "";
    var id = jehon.uuid();
    if ((typeof(params.required) != "undefined") && params.required) required = " required='required' myrequired='required'"
    switch(params.type) {
        case 'integer':
            return chunk.write("<input name='" + params.name + "' type='number'" + required + " value='" + jehon.exists(params.value, "") + "' />");
        case 'string':
            return chunk.write("<input name='" + params.name + "' type='text'" + required + " maxlength='255' value='" + jehon.exists(params.value, "") + "' />");
        case 'list':
            var list = jehon.stringToObject(params.list);
            if (_(list).keys().length <= 6) {
                chunk.write("<table width='100%'><colgroup span='2' width='50%' /><tr><td>");
                params.type = "radios";
                params.separator = function(i, n) {
                    if (( ((i+1)/n) >= 0.5) && ( (i/n) < 0.5)) 
                        return "</td><td style='border-left: solid 1px gray'>";
                    else
                        return "<br/>";
                };
                jehon.settings.templatehelpers.list(chunk, context, bodies, params);
                return chunk.write("</td></tr></table>");
            } else {
                params.type = "select";
                return jehon.settings.templatehelpers.list(chunk, context, bodies, params);
            }
        case 'timestamp':
            return chunk.write(jehon.div.error("impossible to edi a timestamp field"));
        case 'datetime':
        // TODO: required?
            chunk.write("<input name='" + params.name + "' type='date' value='" + params.value + "' id='" + id + "'>");
            return chunk.write("<img src='/cryptomedic/img/nullise.gif' onclick='jQuery(\"#" + id + "\").val(\"\");' alt='set empty date'>");
        case 'text':
            return chunk.write("<textarea name='" + params.name + "' cols='30' rows='6'" + required + " >" + params.value + "</textarea>");
        case 'boolean':
            chunk.write("<input type='hidden' name='" + params.name + "' value='" + params.value + "'>");
            return chunk.write("<input type='checkbox' name='" + params.name + "' value='1'>");
    }
    return chunk.write("edit: " + params.type + " - " + params.value + " -");
};

var amd = {};
amd.display = function(object, id, mode) {
    console.log(mode);
    amd.mode = mode;
    var tstart = new Date().getTime();
    jQuery.getJSON("/amd/" + object + "/view/" + id, function(data) {
        console.log(data);
        var lt = new Date().getTime() - tstart; 
        tstart = new Date().getTime(); 
        jehon.template.render(object, data, '#content');
        jehon.showMode(amd.mode);
        var ld = new Date().getTime() - tstart;
        jQuery("#content").prepend("<div style='color: red'>" + object + "#" + id + "="  + amd.mode + " download time: " + lt + "ms - display time: " + ld + "ms</div>");
        jehon.template.render('patients_belongs', data.belongs, '#belongsTo');
    });
}

amd.bmi = function(height, weight) {
    return 10000 * weight / (height * height);
};

amd.pn = function(n, dec) {
    if (n == NaN) return "Not a number";
    if (isNaN(parseInt(n))) return n;
    if (dec == "%")
        return Math.round(n * 100) + "%";
    return Math.round(n * Math.pow(10, dec)) / Math.pow(10, dec);
};

amd.reference_submit_for_create = function() {
    jQuery("#ForceCreate").val(true);
    jQuery(document.forms[0]).submit();
};

amd.browserDescription = function() {
    var res = "";
    res += window.navigator.userAgent;
    return res;
};


// -------------------------- Graphiques ----------------------------------
amd.graphic = {};
/*
amd.graphic.one = function(what, sex, axis, datas) {
    var lines = [];
    var options = {
            colors: [ (('m' == sex) ? '#00b8a8' : '#fca8a8'), 'white', 'white', 'red' ],
            opacity: [ 1, 1, 1 ],
            shade: [ true, false, true, false ],
            nostroke: [ true, false, true, false ],
            smooth: [ false, false, false, true ],
                symbol: [ "", "", "", "x" ],
            axisxstep: 10,
            gutter: 30,
            absolute: {
                maxX: 1000,
                maxY: 1000
            }
    };

 
    if (sex == 'f' || sex == 'm') {
        lines = [ amd_stats[sex][what].max, amd_stats[sex][what].medium, amd_stats[sex][what].min ];
    } else {
        lines = [ amd_stats['m'][what].max, amd_stats['f'][what].medium, amd_stats['f'][what].min ];
        options.colors[0] = 'gray';
    }
    //if (datas.length > 0)
    //    lines[lines.length] = datas;

    // OLD jehon.math.graphic:
    var target = jQuery('#' + 'stats_graph_' + what);
    if (target.length != 1) return;

    var datax = [];
    var datay = [];
    var axisymin = 10000;
    for (var l = 0; l < lines.length; l++) {
        datax[l] = [];
        datay[l] = [];
        for (var i = 0; i < lines[l].length; i++) {
            if (isNaN(lines[l][i][0]) || isNaN(lines[l][i][0])) continue;
            if (typeof(options.absolute) != 'undefined') {
                if ((typeof(options.absolute.maxX) != 'undefined') && lines[l][i][0] > options.absolute.maxX) continue;
                if ((typeof(options.absolute.minX) != 'undefined') && lines[l][i][0] < options.absolute.minX) continue;
                if ((typeof(options.absolute.maxY) != 'undefined') && lines[l][i][1] > options.absolute.maxY) continue;
                if ((typeof(options.absolute.minY) != 'undefined') && lines[l][i][1] < options.absolute.minY) continue;
            }
            datax[l][i] = lines[l][i][0];
            datay[l][i] = lines[l][i][1];
            if (lines[l][i][1] < axisymin) axisymin = Math.floor(lines[l][i][1]);
        }
    }

    // This script has a difficulty: it expect the numbers to have the decimal separator "." (ex: 10.5) instead of ","
    // This made some problems in the xls sheet in conversions...
    var canvas = Raphael('stats_graph_' + what);
    //canvas.g.txtattr.font = "7px 'Fontin Sans', Fontin-Sans, sans-serif";
    canvas.g.txtattr.font = "12px 'Fontin Sans', Fontin-Sans, sans-serif";

    var width = target.width(); // complete graphical size
    var height = target.height(); // complete graphical size
    var jgraph = canvas.g.linechart(0, 0, width, height, datax, datay, jQuery.extend( 
            { 
                axis: "0 0 1 1", 
                miny: axisymin
            }, options));
    canvas.g.txtattr.font = "9px 'Fontin Sans', Fontin-Sans, sans-serif";
};

amd.extract2D = function(ajax, x, y) {
    // Ajax to be added in header
    var res = [];
    var j = 0;
    for(var i=0; i<ajax.related.length; i++) {
        var dx, dy, dl;
        dl = i; 
        //dl = ajax.related[i].Date.substr(0, 10);
        if (y == 'bmi') {
            if (!('Heightcm' in ajax.related[i])) continue;
            if (!('Weightkg' in ajax.related[i])) continue;
            dy = amd.bmi(ajax.related[i]['Heightcm'], ajax.related[i]['Weightkg']);
        } else {
            if (!(y in ajax.related[i])) continue;
            dy = parseInt(ajax.related[i][y]);
        }
        if (x == 'age') {
            if (!('Date' in ajax.related[i])) continue;
            dx = ajax.related[i].Date.substr(0, 4) - ajax.Yearofbirth;
            if (dx > 20) continue;
        } else {
            if (!(x in ajax.related[i])) continue;
            dx = parseInt(ajax.related[i][x]);
        }
        if ((dx == 0) || isNaN(dx)) continue;
        if ((dy == 0) || isNaN(dy)) continue;
        res[j] = [dx, dy, dl];
        j = j + 1;
    }
    return res;
};
*/

amd.graphic.one = function(what, sex, axis, datas) {
    if (sex == '') sex = 'u';
    // TODO: add version info
    console.log(version);
    jQuery('#' + 'stats_graph_' + what).html("<img src='/cryptomedic/img/graphics/" + what + "-" + sex + ".png'>");
}

amd.graphic.all = function(ajax) {
    var sex = '';
    if (ajax.Sex == 207) sex = 'm';
    if (ajax.Sex == 206) sex = 'f';

    // Fill in all graphics
    amd.graphic.one('weight', sex, { x: 'age', y: 'weight' }, amd.extract2D(ajax, 'age', 'Weightkg'));
    amd.graphic.one('height', sex, { x: 'age', y: 'height' }, amd.extract2D(ajax, 'age', 'Heightcm'));
    amd.graphic.one('wh',     sex, { x: 'height', y: 'weight' }, amd.extract2D(ajax, 'Heightcm', 'Weightkg'));
    amd.graphic.one('BMI',    sex, { x: 'age', y: 'bmi' },    amd.extract2D(ajax, 'age', 'bmi'));
};

amd.fillin = function(ajax) {
    if (amd.status.action != 'view') {
        console.log("not a view");
        return;
    }
    
    if (ajax.Yearofbirth >= 1900) {
        jQuery('#stats_base_actualage').html((new Date().getFullYear() - ajax.Yearofbirth) + " years old today");
    } else {
        jQuery("#stats_base_actualage").html("#Year of birth unknown#");
    }

    if (ajax.Sex < 1) {
        jQuery('#stats_ds_height').html("#sex unknown#");
        jQuery('#stats_ds_weight').html("#sex unknown#");
        jQuery('#stats_base_bmi').html("#sex unknown#");
        jQuery('#stats_ds_wh').html("#sex unknown#");
        jQuery('#stats_ds_bmi').html("#sex unknown#");
    } else {
        jQuery("#stats_base_age").html("#age, year of birth, date of consultation unknown#");
        jQuery('#stats_base_bmi').html("#height or weigth unknown#")
        jQuery('#stats_base_wh').html("#height or weigth unknown#")
        jQuery('#stats_ds_height').html("#height or age unknown#")
        jQuery('#stats_ds_weight').html("#weigth or age unknown#")
        jQuery('#stats_ds_wh')   .html("#height or weigth unknown#")
        jQuery('#stats_ds_bmi')  .html("#height, weigth or age unknown#")

        if (amd.status.ref < 0) {
            jehon.trace("No reference found");
            return 1;
        }
        var el = ajax.related[amd.status.ref];
        var sex = (ajax.Sex == 207 ? 'm' : 'f');
        var age = el.Date.substr(0, 4) - ajax.Yearofbirth;

        if (age > 0) {
            jQuery('#stats_base_age').html(age + " years old at that time of consultation");
        }

        if (!isNaN(parseInt(el.Heightcm)) && (el.Heightcm > 0) && (age > 0)) {
            jQuery('#stats_ds_height').html(amd.pn(jehon.math.stdDeviation(amd_stats[sex]['height'], age, el.Heightcm), 1) + ' sd');
        }
    
        if (!isNaN(parseInt(el.Weightkg)) && (el.Weightkg > 0) && (age > 0)) {
            jQuery('#stats_ds_weight').html(amd.pn(jehon.math.stdDeviation(amd_stats[sex]['weight'], age, el.Weightkg), 1) + ' sd');
        }
    
        if (!isNaN(parseInt(el.Heightcm)) && (el.Heightcm > 0) && !isNaN(parseInt(el.Weightkg)) && (el.Weightkg > 0)) {
            var bmi = amd.bmi(el.Heightcm, el.Weightkg);
            jQuery('#stats_base_bmi').html(amd.pn(bmi, 2));
            console.log(el.Weightkg/el.Heightcm);
            jQuery('#stats_base_wh').html(Math.floor(el.Weightkg/el.Heightcm * 100) / 100);
            jQuery('#stats_ds_wh')   .html(amd.pn(jehon.math.stdDeviation(amd_stats[sex]['wh'], el.Heightcm, el.Weightkg), 1) + ' sd');
            if (age > 0) {
                jQuery('#stats_ds_bmi')  .html(amd.pn(jehon.math.stdDeviation(amd_stats[sex]['BMI'], age, bmi), 1) + ' sd');
            }
        }
    }
};
